Instructions for Readers Using QlikView Personal Edition

The QlikView Personal Edition (PE) can only open QlikView documents created locally on your computer.  So, if you are downloading and installing QlikView for the first time, or you who don�t have a full QlikView license and are using the QlikView PE, please perform the following steps before starting the exercises included in this book.

1.	Launch QlikView.
2.	In the File menu, click New�
3.	If the new file wizard appears, click Cancel.
4.	In the new QlikView document, return to the File menu and click Save.
5.	Browse to where the exercise files are located and in the folder Exercises\Original\, save the new file as  	Sales_Project_Analysis_Sandbox.qvw and replace the existing file.
6.	Once saved, go to the File menu and click Edit Script�
7.	In the Edit Script window, delete all the existing script and insert the following text.

	$(Include=..\supporting files\script\script.txt);

8.	In the File menu, click Reload.
9.	In the Sheet Properties window that appears after the data is reloaded, click OK.
10.	Finally, return to the File menu and click Save.
11.	Repeat the steps 2-10 to create a second QlikView file called Sales_Project_Dashboard.qvw in the same folder.

You are now ready to begin the exercises.
